module.exports = require('./resourceController')('Customers');
