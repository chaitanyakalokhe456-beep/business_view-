module.exports = require('./resourceController')('Inventory');
