module.exports = require('./resourceController')('Sales');
