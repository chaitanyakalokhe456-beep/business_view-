module.exports = require('./resourceController')('Expenses');
