const { randomBytes, randomUUID, scryptSync, timingSafeEqual } = require('node:crypto');
const database = require('../db');
const loadSession = require('../middleware/session');

const SESSION_DURATION_MS = 7 * 24 * 60 * 60 * 1000;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const hashPassword = (password, salt = randomBytes(16).toString('hex')) => {
  const derivedKey = scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derivedKey}`;
};

function setSessionCookie(response, token) {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  response.setHeader('Set-Cookie', `${loadSession.cookieName}=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${SESSION_DURATION_MS / 1000}${secure}`);
}

function clearSessionCookie(response) {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  response.setHeader('Set-Cookie', `${loadSession.cookieName}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0${secure}`);
}

function createSession(userId, response) {
  const token = randomBytes(32).toString('base64url');
  database.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)')
    .run(loadSession.hashToken(token), userId, Date.now() + SESSION_DURATION_MS);
  setSessionCookie(response, token);
}

function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email };
}

function normalizeCredentials(body) {
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
  const password = typeof body.password === 'string' ? body.password : '';
  return { name, email, password };
}

function validateEmail(email) {
  return email.length <= 254 && EMAIL_PATTERN.test(email);
}

function register(request, response, next) {
  const { name, email, password } = normalizeCredentials(request.body);
  if (!name || name.length > 100) return response.status(400).json({ error: 'Enter a name (up to 100 characters).' });
  if (!validateEmail(email)) return response.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 8 || password.length > 128) return response.status(400).json({ error: 'Password must be between 8 and 128 characters.' });

  try {
    const id = randomUUID();
    database.prepare('INSERT INTO users (id, name, email, password_hash) VALUES (?, ?, ?, ?)')
      .run(id, name, email, hashPassword(password));
    createSession(id, response);
    return response.status(201).json({ user: { id, name, email } });
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      return response.status(409).json({ error: 'An account with this email already exists.' });
    }
    return next(error);
  }
}

function login(request, response) {
  const { email, password } = normalizeCredentials(request.body);
  if (!validateEmail(email) || !password || password.length > 128) {
    return response.status(401).json({ error: 'Email or password is incorrect.' });
  }

  const user = database.prepare('SELECT id, name, email, password_hash FROM users WHERE email = ?').get(email);
  if (!user) return response.status(401).json({ error: 'Email or password is incorrect.' });

  const [salt, storedHash] = user.password_hash.split(':');
  const actualHash = Buffer.from(hashPassword(password, salt).split(':')[1], 'hex');
  const expectedHash = Buffer.from(storedHash, 'hex');
  if (actualHash.length !== expectedHash.length || !timingSafeEqual(actualHash, expectedHash)) {
    return response.status(401).json({ error: 'Email or password is incorrect.' });
  }

  createSession(user.id, response);
  return response.json({ user: publicUser(user) });
}

function currentUser(request, response) {
  return response.json({ user: request.user ? publicUser(request.user) : null });
}

function logout(request, response) {
  const token = request.headers.cookie?.split(';')
    .map((value) => value.trim())
    .find((value) => value.startsWith(`${loadSession.cookieName}=`))
    ?.slice(loadSession.cookieName.length + 1);
  if (token) database.prepare('DELETE FROM sessions WHERE token_hash = ?').run(loadSession.hashToken(token));
  clearSessionCookie(response);
  return response.json({ success: true });
}

function updateProfile(request, response, next) {
  if (!request.user) return response.status(401).json({ error: 'Authentication required.' });

  const name = typeof request.body.name === 'string' ? request.body.name.trim() : '';
  const email = typeof request.body.email === 'string' ? request.body.email.trim().toLowerCase() : '';
  if (!name || name.length > 100) return response.status(400).json({ error: 'Enter a name (up to 100 characters).' });
  if (!validateEmail(email)) return response.status(400).json({ error: 'Enter a valid email address.' });

  try {
    database.prepare('UPDATE users SET name = ?, email = ? WHERE id = ?').run(name, email, request.user.id);
    return response.json({ user: { id: request.user.id, name, email } });
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      return response.status(409).json({ error: 'An account with this email already exists.' });
    }
    return next(error);
  }
}

module.exports = { register, login, currentUser, logout, updateProfile };
