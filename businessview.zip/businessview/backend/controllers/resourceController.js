function notImplemented(resource, action) {
  return (request, response) => response.status(501).json({ error: `${resource} ${action} is not implemented yet` });
}

function createResourceController(resource) {
  return {
    list: notImplemented(resource, 'list'),
    getById: notImplemented(resource, 'lookup'),
    create: notImplemented(resource, 'creation'),
    update: notImplemented(resource, 'update'),
    remove: notImplemented(resource, 'deletion'),
  };
}

module.exports = createResourceController;
