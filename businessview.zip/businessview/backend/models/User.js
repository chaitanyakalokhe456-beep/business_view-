class User {
  constructor({ id, name, email, passwordHash, role = 'user', createdAt = new Date() }) {
    this.id = id;
    this.name = name;
    this.email = email;
    this.passwordHash = passwordHash;
    this.role = role;
    this.createdAt = createdAt;
  }
}

module.exports = User;
