class Sale {
  constructor({ id, customerId, items = [], total = 0, createdAt = new Date() }) {
    this.id = id;
    this.customerId = customerId;
    this.items = items;
    this.total = total;
    this.createdAt = createdAt;
  }
}

module.exports = Sale;
