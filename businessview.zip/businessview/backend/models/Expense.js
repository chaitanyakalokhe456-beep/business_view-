class Expense {
  constructor({ id, description, amount = 0, category, date = new Date() }) {
    this.id = id;
    this.description = description;
    this.amount = amount;
    this.category = category;
    this.date = date;
  }
}

module.exports = Expense;
