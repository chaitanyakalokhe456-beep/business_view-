class Customer {
  constructor({ id, name, email, phone = '', createdAt = new Date() }) {
    this.id = id;
    this.name = name;
    this.email = email;
    this.phone = phone;
    this.createdAt = createdAt;
  }
}

module.exports = Customer;
