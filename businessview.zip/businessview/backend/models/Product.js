class Product {
  constructor({ id, name, sku, quantity = 0, unitPrice = 0, createdAt = new Date() }) {
    this.id = id;
    this.name = name;
    this.sku = sku;
    this.quantity = quantity;
    this.unitPrice = unitPrice;
    this.createdAt = createdAt;
  }
}

module.exports = Product;
