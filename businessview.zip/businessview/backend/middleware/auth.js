function requireAuth(request, response, next) {
  if (!request.user) {
    return response.status(401).json({ error: 'Authentication required' });
  }

  return next();
}

module.exports = requireAuth;
