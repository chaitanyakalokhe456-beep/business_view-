const WINDOW_MS = 15 * 60 * 1000;
const MAX_ATTEMPTS = 10;
const attemptsByAddress = new Map();

function authRateLimit(request, response, next) {
  const now = Date.now();
  const address = request.ip || request.socket.remoteAddress || 'unknown';
  let entry = attemptsByAddress.get(address);
  if (!entry || entry.resetAt <= now) {
    entry = { count: 0, resetAt: now + WINDOW_MS };
    attemptsByAddress.set(address, entry);
  }

  if (attemptsByAddress.size > 1000) {
    for (const [key, value] of attemptsByAddress) {
      if (value.resetAt <= now) attemptsByAddress.delete(key);
    }
  }

  entry.count += 1;
  if (entry.count > MAX_ATTEMPTS) {
    response.setHeader('Retry-After', Math.ceil((entry.resetAt - now) / 1000));
    return response.status(429).json({ error: 'Too many account attempts. Please try again later.' });
  }
  return next();
}

module.exports = authRateLimit;
