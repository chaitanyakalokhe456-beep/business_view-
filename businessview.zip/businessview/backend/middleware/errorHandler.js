function errorHandler(error, request, response, next) {
  if (response.headersSent) {
    return next(error);
  }

  const status = error.statusCode || 500;
  return response.status(status).json({ error: status === 500 ? 'Internal server error' : error.message });
}

module.exports = errorHandler;
