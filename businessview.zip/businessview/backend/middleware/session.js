const { createHash } = require('node:crypto');
const database = require('../db');

const COOKIE_NAME = 'businessview_session';

function getSessionToken(request) {
  const cookies = request.headers.cookie?.split(';') ?? [];
  const cookie = cookies.map((value) => value.trim()).find((value) => value.startsWith(`${COOKIE_NAME}=`));
  return cookie ? cookie.slice(COOKIE_NAME.length + 1) : null;
}

function hashToken(token) {
  return createHash('sha256').update(token).digest('hex');
}

function loadSession(request, response, next) {
  const token = getSessionToken(request);
  if (!token) return next();

  const session = database.prepare(`
    SELECT users.id, users.name, users.email
    FROM sessions
    JOIN users ON users.id = sessions.user_id
    WHERE sessions.token_hash = ? AND sessions.expires_at > ?
  `).get(hashToken(token), Date.now());

  if (session) request.user = session;
  return next();
}

loadSession.hashToken = hashToken;
loadSession.cookieName = COOKIE_NAME;

module.exports = loadSession;
