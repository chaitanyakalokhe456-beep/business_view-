const express = require('express');
const controller = require('../controllers/authController');
const authRateLimit = require('../middleware/authRateLimit');

const router = express.Router();
router.post('/register', authRateLimit, controller.register);
router.post('/login', authRateLimit, controller.login);
router.get('/me', controller.currentUser);
router.post('/logout', controller.logout);
router.patch('/profile', controller.updateProfile);

module.exports = router;
