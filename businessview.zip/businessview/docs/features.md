# Feature List

## Available in the frontend prototype

- Dashboard with sales, expenses, profit, order, stock, trend, top-product, and low-stock views
- Sales analysis with daily, weekly, monthly, and product breakdowns
- Expense entry, categories, and expense breakdown chart
- Searchable inventory with stock-in and stock-sold adjustments
- Customer records, purchase totals, regular-customer counts, and purchase history
- CSV sales, expense, profit, and inventory reports
- Filterable and dismissible low-stock, sales, expense, and payment alerts
- Business profile, currency, account, notification, security, and export settings

## Future feature

- Business AI is available as a small local assistant preview. It answers a limited set of questions from records in the current browser and does not call an AI model.
- AI-generated insights, forecasts, and recommendations remain future work and are not a primary navigation feature.

## Prototype limitations

New accounts start with an empty workspace; the dashboard optionally offers clearly labeled fictional City Mart example data for preview. Business records are saved in browser storage and are not synchronized between devices. Authentication is backed by the local API; sales, expense, inventory, and customer API handlers are not implemented yet.
