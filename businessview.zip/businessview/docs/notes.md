# Project Notes

- `frontend/src/pages/AIInsights` is intentionally empty.
- API handlers currently return HTTP 501 until data access and business rules are implemented.
- `database/schema.sql` is a starter SQLite-compatible schema; choose and configure the production database before adding migrations.
- The frontend starts with empty business records and stores user-entered data in browser `localStorage` under `businessview.workspace.v1`.
- This local-only prototype is not secure authentication and does not isolate records between authenticated users. Do not enter sensitive production data.
- Clear the current browser workspace by removing the `businessview.workspace.v1` localStorage key.
- Configure the frontend API URL with `VITE_API_BASE_URL` when running the frontend.
