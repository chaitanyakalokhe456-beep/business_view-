import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { api } from '../services/api';
import { setWorkspaceUser } from '../data/businessData';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState('');

  useEffect(() => {
    setWorkspaceUser(user?.id ?? null);
  }, [user?.id]);

  useEffect(() => {
    let active = true;
    async function restoreSession() {
      let lastError;
      for (let attempt = 0; attempt < 3; attempt += 1) {
        try {
          const { user: currentUser } = await api.get('/auth/me');
          if (active) setUser(currentUser);
          return;
        } catch (error) {
          lastError = error;
          if (attempt < 2) await new Promise((resolve) => window.setTimeout(resolve, 500));
        }
      }
      if (active) {
        setAuthError(`Account service is unavailable. Run "npm run dev" from the project folder and reload. (${lastError.message})`);
      }
    }
    restoreSession().finally(() => {
      if (active) setLoading(false);
    });
    return () => { active = false; };
  }, []);

  async function authenticate(path, credentials) {
    const result = await api.post(path, credentials);
    setUser(result.user);
    setAuthError('');
    return result.user;
  }

  async function signOut() {
    await api.post('/auth/logout');
    setUser(null);
  }

  async function updateUser(profile) {
    const result = await api.patch('/auth/profile', profile);
    setUser(result.user);
    return result.user;
  }

  const value = useMemo(() => ({
    user,
    loading,
    authError,
    signIn: (credentials) => authenticate('/auth/login', credentials),
    signUp: (credentials) => authenticate('/auth/register', credentials),
    signOut,
    updateUser,
  }), [user, loading, authError]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used inside AuthProvider.');
  return context;
}
