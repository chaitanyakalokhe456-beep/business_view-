export function formatDate(value, locale = 'en-US', options = { year: 'numeric', month: 'short', day: 'numeric' }) {
  return new Intl.DateTimeFormat(locale, options).format(new Date(value));
}
