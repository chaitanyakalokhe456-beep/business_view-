import { Send, Sparkles, X } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { money, useBusinessData } from '../data/businessData';
import { translate } from '../utils/localization';

function includesTerm(text, terms) {
  return terms.some((term) => text.includes(term));
}

function answerQuestion(question, data, t) {
  const query = question.toLowerCase();
  const salesTotal = data.sales.reduce((sum, sale) => sum + sale.amount, 0);
  const expenseTotal = data.expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const orders = data.sales.length;
  const lowStock = data.products.filter((product) => product.stock <= product.reorder);

  if (includesTerm(query, ['summary', 'summarize', 'summarise', 'overview', 'business report', 'business status', 'सारांश', 'अवलोकन', 'आढावा', 'सारांश', 'సారాంశం', 'సమీక్ష'])) {
    const topProduct = [...data.products].filter((product) => product.sold > 0).sort((left, right) => right.sold - left.sold)[0];
    const expenseCategories = Object.entries(data.expenses.reduce((groups, expense) => {
      groups[expense.category] = (groups[expense.category] ?? 0) + expense.amount;
      return groups;
    }, {})).sort((left, right) => right[1] - left[1]);
    const nextStep = lowStock.length
      ? t('assistant.summaryNextStock', { items: lowStock.map((product) => product.name).join(', ') })
      : orders === 0
        ? t('assistant.summaryNextSales')
        : data.expenses.length === 0
          ? t('assistant.summaryNextExpenses')
          : t('assistant.summaryNextGood');

    return t('assistant.fullSummary', {
      sales: money(salesTotal),
      orders,
      expenses: money(expenseTotal),
      profit: money(salesTotal - expenseTotal),
      topProduct: topProduct ? `${topProduct.name} (${topProduct.sold})` : t('assistant.summaryNoProduct'),
      category: expenseCategories[0]?.[0] ?? t('assistant.summaryNoCategory'),
      categoryAmount: expenseCategories.length ? money(expenseCategories[0][1]) : money(0),
      lowStock: lowStock.length ? lowStock.map((product) => `${product.name} (${product.stock})`).join(', ') : t('assistant.summaryNoLowStock'),
      customers: data.customers.length,
      nextStep,
    });
  }

  if (includesTerm(query, ['stock', 'inventory', 'reorder', 'product', 'products', 'स्टॉक', 'इन्वेंटरी', 'उत्पाद', 'साठा', 'उत्पादन', 'నిల్వ', 'స్టాక్', 'ఉత్పత్తి'])) {
    const matchedProduct = data.products.find((product) => query.includes(product.name.toLowerCase()));
    if (matchedProduct) {
      return t('assistant.product', { name: matchedProduct.name, stock: matchedProduct.stock, reorder: matchedProduct.reorder, status: t(matchedProduct.stock <= matchedProduct.reorder ? 'assistant.productLow' : 'assistant.productOkay') });
    }
    if (data.products.length === 0) return t('assistant.stockNone');
    if (lowStock.length === 0) return t('assistant.stockOkay', { count: data.products.length });
    return t('assistant.stockLow', { items: lowStock.map((product) => `${product.name} (${product.stock})`).join(', ') });
  }

  if (includesTerm(query, ['expense', 'expenses', 'spending', 'cost', 'costs', 'खर्च', 'खर्चे', 'खर्च', 'ఖర్చు', 'ఖర్చులు'])) {
    if (data.expenses.length === 0) return t('assistant.expenseNone');
    const categories = Object.entries(data.expenses.reduce((groups, expense) => {
      groups[expense.category] = (groups[expense.category] ?? 0) + expense.amount;
      return groups;
    }, {})).sort((left, right) => right[1] - left[1]);
    return t('assistant.expenseSummary', { total: money(expenseTotal), count: data.expenses.length, category: categories[0][0], amount: money(categories[0][1]) });
  }

  if (includesTerm(query, ['profit', 'margin', 'business summary', 'summarize', 'summarise', 'overview', 'how is my business', 'नफा', 'लाभ', 'मुनाफा', 'सारांश', 'లాభం', 'సారాంశం'])) {
    return t('assistant.businessSummary', { sales: money(salesTotal), orders, expenses: money(expenseTotal), profit: money(salesTotal - expenseTotal), products: data.products.length, customers: data.customers.length });
  }

  if (includesTerm(query, ['customer', 'customers', 'buyer', 'buyers', 'ग्राहक', 'कस्टमर'])) {
    if (data.customers.length === 0) return t('assistant.customerNone');
    const topCustomer = [...data.customers].sort((left, right) => right.spent - left.spent)[0];
    return t('assistant.customerSummary', { count: data.customers.length, name: topCustomer.name, amount: money(topCustomer.spent) });
  }

  if (includesTerm(query, ['increase', 'grow', 'boost', 'improve', 'बढ़', 'बढ़ाएं', 'वाढ', 'वाढवा', 'పెంచ', 'మెరుగుపరచ']) && includesTerm(query, ['sales', 'sale', 'revenue', 'business', 'विक्री', 'बिक्री', 'అమ్మకాలు', 'అమ్మకం'])) {
    if (orders === 0) return t('assistant.growthNone');
    const topProduct = [...data.products].sort((left, right) => right.sold - left.sold)[0];
    const suggestionsForGrowth = [];
    if (topProduct?.sold) suggestionsForGrowth.push(t('growth.top', { name: topProduct.name, count: topProduct.sold }));
    if (lowStock.length) suggestionsForGrowth.push(t('growth.restock', { items: lowStock.map((product) => product.name).join(', ') }));
    if (data.customers.length) suggestionsForGrowth.push(t('growth.repeat'));
    if (suggestionsForGrowth.length === 0) suggestionsForGrowth.push(t('growth.track'));
    return t('assistant.growth', { sales: money(salesTotal), orders, ideas: suggestionsForGrowth.join('; ') });
  }

  const asksAboutDecliningSales = includesTerm(query, ['sales', 'sale', 'revenue', 'विक्री', 'बिक्री', 'అమ్మకాలు', 'అమ్మకం'])
    && includesTerm(query, ['low', 'down', 'drop', 'decreas', 'fall', 'declin', 'कम', 'घट', 'कमी', 'कमी', 'తగ్గ', 'తక్కువ']);
  if (asksAboutDecliningSales || includesTerm(query, ['sales are low', 'sales low', 'sales dropped', 'sales down', 'sales decreased', 'sales falling', 'बिक्री कम', 'बिक्री घट', 'विक्री कमी', 'విక్రయాలు తగ్గ'])) {
    if (orders === 0) return t('assistant.salesNone');
    const topProduct = [...data.products].filter((product) => product.sold > 0).sort((left, right) => right.sold - left.sold)[0];
    const lowItems = lowStock.length ? lowStock.map((product) => `${product.name} (${product.stock})`).join(', ') : t('assistant.summaryNoLowStock');
    const response = t('assistant.salesConcern', { sales: money(salesTotal), orders, lowStock: lowItems });
    return topProduct ? `${response}${t('assistant.salesConcernTop', { name: topProduct.name, count: topProduct.sold })}` : response;
  }

  if (includesTerm(query, ['what should i do', 'what do i do', 'next step', 'help me', 'recommend', 'suggest', 'advice', 'problem', 'issue', 'क्या करूं', 'क्या करना चाहिए', 'सलाह', 'मदत करा', 'काय करू', 'पुढे काय', 'सल्ला', 'ఏం చేయాలి', 'సలహా', 'సహాయం చేయండి'])) {
    if (data.sales.length + data.expenses.length + data.products.length === 0) return t('assistant.helpEmpty');
    const recommendations = [];
    if (lowStock.length) recommendations.push(t('advice.restock', { items: lowStock.map((product) => `${product.name} (${product.stock})`).join(', ') }));
    if (orders === 0) recommendations.push(t('advice.recordSales'));
    if (data.expenses.length === 0) recommendations.push(t('advice.recordExpenses'));
    if (data.customers.length === 0 && orders > 0) recommendations.push(t('advice.trackCustomers'));
    if (recommendations.length === 0) {
      const bestSeller = [...data.products].filter((product) => product.sold > 0).sort((left, right) => right.sold - left.sold)[0];
      recommendations.push(bestSeller ? t('advice.focusProduct', { name: bestSeller.name }) : t('assistant.helpOkay'));
    }
    return t('assistant.advice', { recommendations: recommendations.join('; ') });
  }

  if (includesTerm(query, ['sale', 'sales', 'revenue', 'order', 'orders', 'विक्री', 'बिक्री', 'అమ్మకాలు', 'అమ్మకం'])) {
    if (orders === 0) return t('assistant.salesNone');
    const topProduct = [...data.products].sort((left, right) => right.sold - left.sold)[0];
    const summary = t('assistant.salesSummary', { sales: money(salesTotal), orders });
    return topProduct?.sold ? `${summary}${t('assistant.salesTop', { name: topProduct.name, count: topProduct.sold })}` : summary;
  }

  if (includesTerm(query, ['help', 'what can you do', 'suggest', 'recommend', 'tip', 'tips', 'मदद', 'सुझाव', 'सहायता', 'मदत', 'सल्ला', 'సహాయం', 'సూచన'])) {
    if (data.sales.length + data.expenses.length + data.products.length === 0) return t('assistant.helpEmpty');
    if (lowStock.length) return t('assistant.help', { items: lowStock.map((product) => product.name).join(', ') });
    return t('assistant.helpOkay');
  }

  return t('assistant.fallback');
}

export default function BusinessAssistant() {
  const data = useBusinessData();
  const language = data.profile.language || 'en';
  const t = (key, values) => translate(language, key, values);
  const suggestions = [t('assistant.suggestion.sales'), t('assistant.suggestion.stock'), t('assistant.suggestion.summary')];
  const followups = [t('assistant.suggestion.summary'), t('assistant.suggestion.advice'), t('assistant.suggestion.expenses')];
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState('');
  const [messages, setMessages] = useState([{ role: 'assistant', text: translate(data.profile.language || 'en', 'assistant.greeting') }]);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }, [messages, open]);

  useEffect(() => {
    setMessages([{ role: 'assistant', text: t('assistant.greeting') }]);
    setDraft('');
  }, [language]);

  function ask(question) {
    const prompt = question.trim();
    if (!prompt) return;
    setMessages((current) => [...current, { role: 'user', text: prompt }, { role: 'assistant', text: answerQuestion(prompt, data, t) }]);
    setDraft('');
  }

  return <div className="assistant-root">
    {open && <section className="assistant-panel" role="dialog" aria-modal="false" aria-labelledby="assistant-title">
      <header className="assistant-head"><span className="assistant-icon"><Sparkles size={17} /></span><span className="assistant-heading"><b id="assistant-title">{t('assistant.title')}</b></span><button className="icon-button assistant-close" onClick={() => setOpen(false)} aria-label={t('assistant.close')}><X size={18} /></button></header>
      <div className="assistant-disclaimer">{t('assistant.disclaimer')}</div>
      <div className="assistant-messages" role="log" aria-live="polite" aria-relevant="additions text">
        {messages.map((message, index) => <div className={`assistant-message ${message.role}`} key={`${message.role}-${index}`}>{message.role === 'assistant' && <i className="assistant-message-mark" aria-hidden="true"><Sparkles size={13} /></i>}<span>{message.text}</span></div>)}
        <div ref={bottomRef} />
      </div>
      <div className="assistant-suggestions">{(messages.length === 1 ? suggestions : followups).map((suggestion) => <button key={suggestion} onClick={() => ask(suggestion)}>{suggestion}</button>)}</div>
      <form className="assistant-composer" onSubmit={(event) => { event.preventDefault(); ask(draft); }}>
        <textarea value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); event.currentTarget.form.requestSubmit(); } }} rows={1} aria-label={t('assistant.placeholder')} placeholder={t('assistant.placeholder')} />
        <button type="submit" disabled={!draft.trim()} aria-label="Send question"><Send size={16} /></button>
      </form>
    </section>}
    <button className={`assistant-launcher${open ? ' is-open' : ''}`} onClick={() => setOpen((current) => !current)} aria-expanded={open} aria-label={open ? t('assistant.close') : t('assistant.open')}>
      {open ? <X size={19} /> : <><Sparkles size={17} /><span>{t('assistant.title')}</span></>}
    </button>
  </div>;
}
