import { Bell, ChevronDown, LayoutDashboard, Package, Settings, Users, ReceiptText, ChartNoAxesCombined, FileBarChart, Languages, LogOut, Menu, Store, UserRound } from 'lucide-react';
import { useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useBusinessData } from '../data/businessData';
import { useAuth } from '../auth/AuthContext';
import { languages, translate } from '../utils/localization';
import BusinessAssistant from './BusinessAssistant';
import '../styles/business.css';

const navGroups = [
  { label: 'WORKSPACE', items: [
    { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { label: 'Sales', path: '/sales', icon: ChartNoAxesCombined },
    { label: 'Expenses', path: '/expenses', icon: ReceiptText },
    { label: 'Inventory', path: '/inventory', icon: Package },
    { label: 'Customers', path: '/customers', icon: Users },
  ] },
  { label: 'MANAGE', items: [
    { label: 'Reports', path: '/reports', icon: FileBarChart },
    { label: 'Alerts', path: '/alerts', icon: Bell },
    { label: 'Settings', path: '/settings', icon: Settings },
  ] },
];

const titles = {
  '/dashboard': ['nav.dashboard', 'page.dashboard.subtitle'],
  '/sales': ['nav.sales', 'page.sales.subtitle'],
  '/expenses': ['nav.expenses', 'page.expenses.subtitle'],
  '/inventory': ['nav.inventory', 'page.inventory.subtitle'],
  '/customers': ['nav.customers', 'page.customers.subtitle'],
  '/reports': ['nav.reports', 'page.reports.subtitle'],
  '/alerts': ['nav.alerts', 'page.alerts.subtitle'],
  '/settings': ['nav.settings', 'page.settings.subtitle'],
};

export default function BusinessLayout() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { alerts, products, profile, updateProfile } = useBusinessData();
  const { user, signOut } = useAuth();
  const [profileActionError, setProfileActionError] = useState('');
  const language = profile.language || 'en';
  const t = (key) => translate(language, key);
  const urgentAlertCount = alerts.length + products.filter((product) => product.stock <= product.reorder).length;
  const [titleKey, subtitleKey] = titles[location.pathname] ?? titles['/dashboard'];

  async function handleSignOut() {
    try {
      await signOut();
      navigate('/');
    } catch (error) {
      setProfileActionError(error.message);
    }
  }

  return (
    <div className="business-app">
      <aside className={`app-sidebar${menuOpen ? ' is-open' : ''}`}>
        <NavLink className="app-brand" to="/dashboard" onClick={() => setMenuOpen(false)}>
          <span className="brand-symbol"><Store size={17} strokeWidth={2.4} /></span>
          <span>BusinessView<small>{t('brand.subtitle')}</small></span>
        </NavLink>
        <div className="business-switcher"><span className="business-avatar">{(profile.businessName || 'B').slice(0, 1).toUpperCase()}</span><span><b>{profile.businessName || t('workspace.yourBusiness')}</b><small>{profile.businessType || t('workspace.type')}</small></span><ChevronDown size={15} /></div>
        <nav className="side-navigation" aria-label="Business sections">
          {navGroups.map((group) => <div className="nav-group" key={group.label}>
            <p>{t(group.label === 'WORKSPACE' ? 'nav.workspace' : 'nav.manage')}</p>
            {group.items.map(({ label, path, icon: Icon, badge }) => <NavLink key={path} to={path} onClick={() => setMenuOpen(false)} className={({ isActive }) => `side-link${isActive ? ' active' : ''}`}>
              <Icon size={17} strokeWidth={1.8} /><span>{t(`nav.${label.toLowerCase()}`)}</span>{label === 'Alerts' && urgentAlertCount > 0 && <i>{urgentAlertCount}</i>}
            </NavLink>)}
          </div>)}
        </nav>
      </aside>

      {menuOpen && <button className="sidebar-scrim" onClick={() => setMenuOpen(false)} aria-label="Close navigation" />}
      <div className="app-main">
        <header className="app-topbar">
          <button className="icon-button mobile-menu" onClick={() => setMenuOpen(true)} aria-label="Open navigation"><Menu size={20} /></button>
          <div className="topbar-heading"><h1>{t(titleKey)}</h1><p>{t(subtitleKey)}</p></div>
          <div className="topbar-actions"><label className="language-picker"><Languages size={15} /><span className="visually-hidden">{t('language.label')}</span><select aria-label={t('language.label')} value={language} onChange={(event) => updateProfile({ language: event.target.value })}>{languages.map((item) => <option value={item.code} key={item.code}>{item.native}</option>)}</select></label><NavLink className="header-alert" to="/alerts" aria-label={t('nav.alerts')}><Bell size={19} />{urgentAlertCount > 0 && <i>{urgentAlertCount}</i>}</NavLink><div className="profile-menu-wrap"><button className="profile-trigger" aria-label={t('profile.menu')} aria-expanded={profileMenuOpen} onClick={() => setProfileMenuOpen((open) => !open)}><span className="user-avatar top-avatar">{(user?.name || 'U').split(' ').map((part) => part[0]).join('').slice(0, 2).toUpperCase()}</span></button>{profileMenuOpen && <div className="profile-menu" role="menu"><div className="profile-menu-heading"><b>{user?.name || t('workspace.user')}</b><small>{user?.email || t('workspace.account')}</small></div>{profileActionError && <p role="alert">{profileActionError}</p>}<button role="menuitem" onClick={() => { setProfileMenuOpen(false); navigate('/settings?section=account'); }}><UserRound size={15} />{t('profile.account')}</button><button role="menuitem" onClick={() => { setProfileMenuOpen(false); navigate('/settings?section=business'); }}><Settings size={15} />{t('profile.settings')}</button><button role="menuitem" onClick={handleSignOut}><LogOut size={15} />{t('profile.signout')}</button></div>}</div></div>
        </header>
        <main className="page-content"><Outlet /></main>
      </div>
      <BusinessAssistant />
    </div>
  );
}
