export default function Button({ children, type = 'button', onClick, variant = 'primary' }) {
  return <button className={`button button--${variant}`} type={type} onClick={onClick}>{children}</button>;
}
