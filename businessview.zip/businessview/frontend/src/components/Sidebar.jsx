const links = [
  ['Dashboard', '/dashboard'],
  ['Sales', '/sales'],
  ['Expenses', '/expenses'],
  ['Inventory', '/inventory'],
  ['Customers', '/customers'],
  ['Reports', '/reports'],
  ['Alerts', '/alerts'],
  ['Settings', '/settings'],
];

export default function Sidebar() {
  return (
    <nav aria-label="Main navigation">
      <a href="/" className="sidebar__brand">BusinessView</a>
      <ul>{links.map(([label, href]) => <li key={href}><a href={href}>{label}</a></li>)}</ul>
    </nav>
  );
}
