export default function BarChart({ title, values = [] }) {
  const maxValue = Math.max(...values.map((item) => item.value), 1);

  return (
    <figure aria-label={title}>
      <figcaption>{title}</figcaption>
      <div className="bar-chart">
        {values.map((item) => (
          <div className="bar-chart__item" key={item.label}>
            <div className="bar-chart__track"><span style={{ height: `${(item.value / maxValue) * 100}%` }} /></div>
            <span>{item.label}</span>
          </div>
        ))}
      </div>
    </figure>
  );
}
