import { lazy, Suspense } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider, useAuth } from './auth/AuthContext';
import BusinessLayout from './components/BusinessLayout';
import Login from './pages/Login/Login';

const Alerts = lazy(() => import('./pages/Alerts/Alerts'));
const Customers = lazy(() => import('./pages/Customers/Customers'));
const Dashboard = lazy(() => import('./pages/Dashboard/Dashboard'));
const Expenses = lazy(() => import('./pages/Expenses/Expenses'));
const Home = lazy(() => import('./pages/Home/Home'));
const Inventory = lazy(() => import('./pages/Inventory/Inventory'));
const Reports = lazy(() => import('./pages/Reports/Reports'));
const Sales = lazy(() => import('./pages/Sales/Sales'));
const Settings = lazy(() => import('./pages/Settings/Settings'));

function RouteLoading() {
  return <p className="route-loading" role="status">Loading workspace…</p>;
}

function ProtectedLayout() {
  const { user, loading } = useAuth();
  if (loading) return <RouteLoading />;
  if (!user) return <Navigate to="/" replace />;
  return <BusinessLayout />;
}

function AppRoutes() {
  const { user, loading } = useAuth();
  return (
    <Suspense fallback={<RouteLoading />}>
      <Routes>
        <Route path="/" element={loading ? <RouteLoading /> : user ? <Navigate to="/dashboard" replace /> : <Login />} />
        <Route path="/home" element={<Home />} />
        <Route element={<ProtectedLayout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/sales" element={<Sales />} />
          <Route path="/expenses" element={<Expenses />} />
          <Route path="/inventory" element={<Inventory />} />
          <Route path="/customers" element={<Customers />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/alerts" element={<Alerts />} />
          <Route path="/settings" element={<Settings />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider><AppRoutes /></AuthProvider>
    </BrowserRouter>
  );
}
