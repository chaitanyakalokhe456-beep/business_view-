import { useState } from 'react';
import { Bell, Building2, Download, Languages, Shield, UserRound, Wallet } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import { useBusinessData } from '../../data/businessData';
import { useAuth } from '../../auth/AuthContext';
import { languages, translate } from '../../utils/localization';

const sections = [
  { key: 'business', label: 'Business profile', icon: Building2 },
  { key: 'currency', label: 'Currency', icon: Wallet },
  { key: 'account', label: 'Account', icon: UserRound },
  { key: 'language', label: 'Language', icon: Languages },
  { key: 'notifications', label: 'Notifications', icon: Bell },
  { key: 'security', label: 'Security', icon: Shield },
];

export default function Settings() {
  const { profile, updateProfile, sales, expenses, products, customers } = useBusinessData();
  const { user, updateUser } = useAuth();
  const t = (key, values) => translate(profile.language, key, values);
  const [searchParams] = useSearchParams();
  const requestedSection = searchParams.get('section');
  const [section, setSection] = useState(sections.some((item) => item.key === requestedSection) ? requestedSection : 'business');
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState('');
  async function saveSettings(event) {
    event.preventDefault();
    const fields = Object.fromEntries(new FormData(event.currentTarget).entries());
    setSaveError('');
    try {
      if (section === 'business') updateProfile({ businessName: fields.businessName, businessType: fields.businessType, email: fields.businessEmail, address: fields.businessAddress });
      if (section === 'currency') updateProfile({ currency: fields.currency });
      if (section === 'account') await updateUser({ name: fields.ownerName, email: fields.ownerEmail });
      if (section === 'language') updateProfile({ language: fields.language });
      setSaved(true);
      window.setTimeout(() => setSaved(false), 2600);
    } catch (error) {
      setSaveError(error.message);
    }
  }

  return <>
    <div className="page-heading-row"><div><h2>{t('settings.title')}</h2><p>{t('settings.subtitle')}</p></div></div>
    <section className="settings-grid">
      <nav className="settings-nav" aria-label="Settings sections">{sections.map(({ key, icon: Icon }) => <button className={section === key ? 'active' : ''} key={key} onClick={() => setSection(key)}><Icon size={15} />{t(`settings.section.${key}`)}</button>)}<button onClick={() => { const csv = [['record_type', 'record_data'], ...sales.map((record) => ['sale', JSON.stringify(record)]), ...expenses.map((record) => ['expense', JSON.stringify(record)]), ...products.map((record) => ['product', JSON.stringify(record)]), ...customers.map((record) => ['customer', JSON.stringify(record)])].map((row) => row.join(',')).join('\n'); const link = document.createElement('a'); link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); link.download = 'businessview-export.csv'; link.click(); URL.revokeObjectURL(link.href); }}><Download size={15} />Data export</button></nav>
      <article className="panel settings-form"><h3>{t(`settings.section.${section}`)}</h3><p>{t('settings.formHint')}</p>
        {saveError && <p role="alert">{saveError}</p>}
        <form className="settings-fields" onSubmit={saveSettings}>
          {section === 'business' && <><div className="form-field"><label htmlFor="business-name">Business name</label><input id="business-name" name="businessName" defaultValue={profile.businessName} placeholder="Enter your business name" /></div><div className="form-field"><label htmlFor="business-type">Business type</label><select id="business-type" name="businessType" defaultValue={profile.businessType}><option value="">Choose business type</option><option>Retail store</option><option>Food and beverage</option><option>Services</option><option>Other</option></select></div><div className="form-field"><label htmlFor="business-email">Business email</label><input id="business-email" name="businessEmail" type="email" defaultValue={profile.email} placeholder="business@example.com" /></div><div className="form-field"><label htmlFor="business-address">Address</label><input id="business-address" name="businessAddress" defaultValue={profile.address} placeholder="Business address" /></div></>}
          {section === 'currency' && <><div className="form-field"><label htmlFor="currency">Display currency</label><select id="currency" name="currency" defaultValue={profile.currency}><option value="INR">INR · Indian Rupee (₹)</option><option value="USD">USD · US Dollar ($)</option><option value="GBP">GBP · British Pound (£)</option><option value="EUR">EUR · Euro (€)</option></select></div><div className="form-field"><label htmlFor="locale">Number format</label><select id="locale" name="locale" defaultValue="en-IN"><option value="en-IN">India (1,23,456)</option><option value="en-US">US (123,456)</option></select></div></>}
          {section === 'account' && <><div className="form-field"><label htmlFor="owner-name">Your name</label><input id="owner-name" name="ownerName" defaultValue={user.name} placeholder="Enter your name" required maxLength={100} /></div><div className="form-field"><label htmlFor="owner-email">Email address</label><input id="owner-email" name="ownerEmail" type="email" defaultValue={user.email} placeholder="you@example.com" required /></div></>}
          {section === 'language' && <><div className="form-field"><label htmlFor="interface-language">{t('profile.language')}</label><select id="interface-language" name="language" value={profile.language || 'en'} onChange={(event) => updateProfile({ language: event.target.value })}>{languages.map((language) => <option value={language.code} key={language.code}>{language.native} · {language.label}</option>)}</select></div><p className="language-help">{t('settings.languageHelp')}</p></>}
          {section === 'notifications' && <>{[['Low stock reminders', 'Get notified when products reach their reorder point.'], ['Weekly sales summary', 'Receive a weekly summary of sales and order activity.'], ['Expense alerts', 'Get a note when expenses rise above the previous month.']].map(([label, help]) => <label className="setting-toggle" key={label}><span><b>{label}</b><small>{help}</small></span><input type="checkbox" defaultChecked /></label>)}</>}
          {section === 'security' && <><div className="notice"><Shield size={16} /><span>Password changes and multi-factor security will be available when account authentication is connected.</span></div><div className="form-field"><label htmlFor="session">Session timeout</label><select id="session" defaultValue="8"><option value="1">1 hour</option><option value="8">8 hours</option><option value="24">24 hours</option></select></div></>}
          <button className="button-primary settings-save" type="submit">{t('settings.save')}</button>
        </form>
      </article>
    </section>
    {saved && <div className="toast-message" role="status">{t('settings.saved')}</div>}
  </>;
}
