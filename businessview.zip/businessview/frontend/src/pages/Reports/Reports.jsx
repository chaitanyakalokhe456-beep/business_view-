import { useState } from 'react';
import { ArrowDownToLine, FileBarChart, IndianRupee, Package, ReceiptText, ShoppingBag } from 'lucide-react';
import { money, useBusinessData } from '../../data/businessData';

const reportTypes = [
  { title: 'Sales report', description: 'Revenue, orders, and product performance', icon: ShoppingBag, type: 'sales' },
  { title: 'Expense report', description: 'Spending by category and date', icon: ReceiptText, type: 'expenses' },
  { title: 'Profit report', description: 'Sales less recorded costs', icon: IndianRupee, type: 'profit' },
  { title: 'Inventory report', description: 'Available stock and current stock value', icon: Package, type: 'inventory' },
];

function downloadReport(type) {
  const reportRows = type === 'sales' ? sales.map((row) => [row.day, row.orders, row.amount])
    : type === 'expenses' ? expenses.map((row) => [row.date, row.category, row.note, row.amount])
    : type === 'inventory' ? products.map((row) => [row.id, row.name, row.stock, row.price, row.stock * row.price])
    : [['This week', sales.reduce((sum, row) => sum + row.amount, 0), expenses.reduce((sum, row) => sum + row.amount, 0), sales.reduce((sum, row) => sum + row.amount, 0) - expenses.reduce((sum, row) => sum + row.amount, 0)]];
  const headers = type === 'sales' ? ['Day', 'Orders', 'Sales INR'] : type === 'expenses' ? ['Date', 'Category', 'Description', 'Amount INR'] : type === 'inventory' ? ['SKU', 'Product', 'Available units', 'Unit price INR', 'Stock value INR'] : ['Period', 'Sales INR', 'Expenses INR', 'Profit INR'];
  const csv = [headers, ...reportRows].map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(',')).join('\n');
  const link = document.createElement('a');
  link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  link.download = `businessview-${type}-report.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

export default function Reports() {
  const { sales, expenses, products } = useBusinessData();
  const [notice, setNotice] = useState('');
  const totalSales = sales.reduce((sum, row) => sum + row.amount, 0);
  const totalExpenses = expenses.reduce((sum, row) => sum + row.amount, 0);

  return <>
    <div className="page-heading-row"><div><h2>Reports library</h2><p>Generate simple summaries from your business records.</p></div><span className="date-chip">All saved records</span></div>
    <section className="report-grid">{reportTypes.map(({ title, description, icon: Icon, type }) => <article className="report-tile" key={type}><span className="kpi-icon"><Icon size={17} /></span><div><b>{title}</b><small>{description}</small></div><button className="icon-button" onClick={() => { downloadReport(type); setNotice(`${title} downloaded as CSV.`); }} title={`Download ${title}`} aria-label={`Download ${title}`}><ArrowDownToLine size={17} /></button></article>)}</section>
    {notice && <p className="inline-success" role="status">{notice} Report uses prototype records.</p>}
    <article className="panel report-summary-panel"><header className="panel-head"><div><h3>Business summary</h3><p>Totals from your saved records</p></div><button className="button-secondary" onClick={() => { downloadReport('profit'); setNotice('Business summary downloaded as CSV.'); }}><FileBarChart size={14} /> Export summary</button></header>
      <div className="summary-strip"><div><small>Total sales</small><b>{money(totalSales)}</b></div><div><small>Total expenses</small><b>{money(totalExpenses)}</b></div><div><small>Profit</small><b>{money(totalSales - totalExpenses)}</b></div><div><small>Orders</small><b>{sales.length}</b></div></div>
      <div className="summary-note">Reports include only records entered in this browser workspace.</div>
    </article>
  </>;
}
