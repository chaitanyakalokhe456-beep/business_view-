import { useMemo, useState } from 'react';
import { Search, UserPlus, Users } from 'lucide-react';
import { money, useBusinessData } from '../../data/businessData';

export default function Customers() {
  const { customers, sales, addCustomer } = useBusinessData();
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState('');
  const [notice, setNotice] = useState('');
  const [showForm, setShowForm] = useState(false);
  const filtered = useMemo(() => customers.filter((customer) => `${customer.name} ${customer.email} ${customer.id}`.toLowerCase().includes(query.toLowerCase())), [query]);
  const selected = customers.find((customer) => customer.id === selectedId);
  const regulars = customers.filter((customer) => customer.visits >= 8).length;

  function saveCustomer(event) {
    event.preventDefault();
    const customer = Object.fromEntries(new FormData(event.currentTarget).entries());
    const customerId = addCustomer(customer);
    setSelectedId(customerId);
    setQuery('');
    setShowForm(false);
    setNotice('Customer added to your workspace.');
  }

  return <>
    <div className="page-heading-row"><div><h2>Customer relationships</h2><p>Customer records and purchasing activity at a glance.</p></div><button className="button-primary" onClick={() => setShowForm((visible) => !visible)}><UserPlus size={15} /> Add customer</button></div>
    {notice && <p className="inline-success" role="status">{notice}</p>}
    {showForm && <form className="form-grid customer-create-form" onSubmit={saveCustomer}><div className="form-field"><label htmlFor="customer-name">Customer name</label><input id="customer-name" name="name" placeholder="Full name" required /></div><div className="form-field"><label htmlFor="customer-email">Email (optional)</label><input id="customer-email" name="email" type="email" placeholder="name@example.com" /></div><div className="form-field"><label htmlFor="customer-phone">Phone (optional)</label><input id="customer-phone" name="phone" type="tel" placeholder="Phone number" /></div><div className="form-actions"><button className="button-primary" type="submit">Save customer</button></div></form>}
    <section className="kpi-grid customer-kpis">
      <article className="kpi-card"><div className="kpi-head">Customers<span className="kpi-icon"><Users size={16} /></span></div><strong className="kpi-value">{customers.length}</strong><div className="kpi-foot"><span>Customer records</span></div></article>
      <article className="kpi-card"><div className="kpi-head">Regular customers<span className="kpi-icon"><Users size={16} /></span></div><strong className="kpi-value">{regulars}</strong><div className="kpi-foot"><span>8 or more visits</span></div></article>
      <article className="kpi-card"><div className="kpi-head">Total purchases<span className="kpi-icon"><Users size={16} /></span></div><strong className="kpi-value">{money(customers.reduce((sum, customer) => sum + customer.spent, 0))}</strong><div className="kpi-foot"><span>Across listed customers</span></div></article>
    </section>
    <section className="customer-layout">
      <article className="panel"><header className="panel-head"><div><h3>Customer list</h3><p>Choose a customer to view purchase history</p></div></header>
        <label className="search-field customer-search"><Search size={15} /><input value={query} onChange={(event) => setQuery(event.target.value)} aria-label="Search customers" placeholder="Search name or email" /></label>
        <div className="customer-list">{filtered.map((customer) => <button className={`customer-row${selectedId === customer.id ? ' selected' : ''}`} key={customer.id} onClick={() => setSelectedId(customer.id)}>
          <span className="customer-avatar">{customer.name.split(' ').map((part) => part[0]).join('')}</span><span className="customer-info"><b>{customer.name}</b><small>{customer.email}</small></span><span className="customer-total"><b>{money(customer.spent)}</b><small>{customer.visits} visits</small></span>
        </button>)}{filtered.length === 0 && <p className="empty-state">{customers.length === 0 ? 'No customers yet. Add your first customer above.' : 'No customers match your search.'}</p>}</div>
      </article>
      <article className="panel customer-detail">{selected ? <>
        <header className="customer-profile"><span className="customer-avatar large">{selected.name.split(' ').map((part) => part[0]).join('')}</span><div><h3>{selected.name}</h3><p>{selected.email}</p></div></header>
        <div className="customer-stats"><div><small>Total purchases</small><b>{money(selected.spent)}</b></div><div><small>Store visits</small><b>{selected.visits}</b></div><div><small>Last purchase</small><b>{selected.lastPurchase}</b></div></div>
        <header className="panel-head detail-heading"><div><h3>Purchase history</h3><p>Recent transactions for this customer</p></div></header>
        <div className="purchase-list">{sales.filter((sale) => sale.customerId === selected.id).map((sale) => <div key={sale.id}><span><b>Sale</b><small>{sale.date}{sale.items?.length ? ` · ${sale.items.length} products` : ''}</small></span><strong>{money(sale.amount)}</strong></div>)}{selected.visits === 0 && <p className="empty-state">Purchases recorded for this customer will appear here.</p>}</div>
      </> : <div className="empty-state">{customers.length === 0 ? 'Add a customer to keep their records and purchase history here.' : 'Select a customer to view their details.'}</div>}</article>
    </section>
  </>;
}
