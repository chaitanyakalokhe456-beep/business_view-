import { useState } from 'react';
import { Bell, Check, CircleAlert, CreditCard, Package } from 'lucide-react';
import { useBusinessData } from '../../data/businessData';

const icons = { Stock: Package, Payment: CreditCard };

export default function Alerts() {
  const { products, alerts, addAlert, removeAlert } = useBusinessData();
  const [filter, setFilter] = useState('All alerts');
  const [showForm, setShowForm] = useState(false);
  const [dismissedStock, setDismissedStock] = useState([]);
  const stockAlerts = products.filter((product) => product.stock <= product.reorder && !dismissedStock.includes(product.id)).map((product) => ({
    id: product.id,
    type: 'Stock',
    title: `${product.name} is running low.`,
    detail: `${product.stock} units left · Reorder point is ${product.reorder}`,
    time: 'Current stock',
    tone: 'warning',
    generated: true,
  }));
  const items = [...stockAlerts, ...alerts];
  const visible = items.filter((item) => filter === 'All alerts' || item.type === filter);

  function saveReminder(event) {
    event.preventDefault();
    const form = Object.fromEntries(new FormData(event.currentTarget).entries());
    addAlert({ type: 'Payment', title: `Payment due to ${form.payee}.`, detail: `${form.amount} due on ${form.dueDate}`, time: form.dueDate, tone: 'neutral' });
    setShowForm(false);
  }

  function dismiss(item) {
    if (item.generated) setDismissedStock((current) => [...current, item.id]);
    else removeAlert(item.id);
  }

  return <>
    <div className="page-heading-row"><div><h2>Needs your attention</h2><p>Alerts based on your stock levels and reminders you create.</p></div><div><select className="date-select" aria-label="Filter alerts" value={filter} onChange={(event) => setFilter(event.target.value)}><option>All alerts</option><option>Stock</option><option>Payment</option></select><button className="button-primary" onClick={() => setShowForm((visible) => !visible)}><CreditCard size={14} /> Add reminder</button></div></div>
    {showForm && <form className="form-grid reminder-form" onSubmit={saveReminder}><div className="form-field"><label htmlFor="reminder-payee">Payee</label><input id="reminder-payee" name="payee" placeholder="Supplier or bill" required /></div><div className="form-field"><label htmlFor="reminder-amount">Amount</label><input id="reminder-amount" name="amount" type="number" min="0.01" step="0.01" placeholder="0.00" required /></div><div className="form-field"><label htmlFor="reminder-date">Due date</label><input id="reminder-date" name="dueDate" type="date" required /></div><div className="form-actions"><button className="button-primary" type="submit">Save reminder</button></div></form>}
    <div className="alert-summary"><span className="summary-alert-icon"><Bell size={17} /></span><span><b>{items.length} active updates</b><small>Review each update and dismiss it when handled.</small></span><span className="status-pill status-low">{items.filter((item) => item.tone === 'warning').length} urgent</span></div>
    <article className="panel alert-page-panel"><header className="panel-head"><div><h3>Recent alerts</h3><p>Latest changes detected in your business activity</p></div><button className="button-quiet" onClick={() => setItems([])}><Check size={14} /> Mark all reviewed</button></header>
      <div className="alert-list">{visible.map((item) => { const Icon = icons[item.type] ?? CircleAlert; return <article className="alert-row" key={item.id}>
        <span className={`alert-type-icon ${item.tone}`}><Icon size={16} /></span><span className="alert-copy"><b>{item.title}</b><p>{item.detail}</p><small>{item.time} · {item.type}</small></span><button className="button-quiet" onClick={() => dismiss(item)} aria-label={`Dismiss alert: ${item.title}`}>Dismiss</button>
      </article>; })}{visible.length === 0 && <p className="empty-state">No alerts yet. Add products to receive stock alerts or create a payment reminder.</p>}</div>
    </article>
    <div className="notice"><CircleAlert size={16} /><span>Low-stock alerts update from your product quantities. Payment reminders are saved in this browser.</span></div>
  </>;
}
