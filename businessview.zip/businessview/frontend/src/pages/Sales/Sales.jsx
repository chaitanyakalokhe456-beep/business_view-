import { Download, IndianRupee, ShoppingBag, TrendingUp } from 'lucide-react';
import { useState } from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { money, useBusinessData } from '../../data/businessData';

export default function Sales() {
  const { sales, products, customers, addSale } = useBusinessData();
  const [period, setPeriod] = useState('Daily');
  const [showForm, setShowForm] = useState(false);
  const [notice, setNotice] = useState('');
  const total = sales.reduce((sum, sale) => sum + sale.amount, 0);
  const rows = [...products].filter((product) => product.sold > 0).sort((a, b) => b.sold - a.sold);
  const chartGroups = new Map();
  sales.forEach((sale) => {
    const date = new Date(`${sale.date}T00:00:00Z`);
    const groupDate = new Date(date);
    if (period === 'Weekly') groupDate.setUTCDate(groupDate.getUTCDate() - ((groupDate.getUTCDay() + 6) % 7));
    if (period === 'Monthly') groupDate.setUTCDate(1);
    const key = period === 'Monthly' ? groupDate.toISOString().slice(0, 7) : groupDate.toISOString().slice(0, 10);
    const point = chartGroups.get(key) ?? { key, amount: 0 };
    point.amount += sale.amount;
    chartGroups.set(key, point);
  });
  const chartRows = [...chartGroups.values()].sort((a, b) => a.key.localeCompare(b.key)).map((point) => ({
    ...point,
    day: period === 'Monthly' ? new Date(`${point.key}-01T00:00:00Z`).toLocaleDateString('en-IN', { month: 'short', year: '2-digit', timeZone: 'UTC' }) : new Date(`${point.key}T00:00:00Z`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', timeZone: 'UTC' }),
  }));

  function saveSale(event) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const product = products.find((item) => item.id === form.get('productId'));
    const quantity = Number(form.get('quantity'));
    if (product && quantity > product.stock) {
      setNotice(`Only ${product.stock} ${product.name} units are currently available.`);
      return;
    }
    addSale({
      date: form.get('date'),
      amount: Number(form.get('amount')),
      customerId: form.get('customerId'),
      items: product ? [{ productId: product.id, quantity, unitPrice: product.price }] : [],
    });
    event.currentTarget.reset();
    setShowForm(false);
    setNotice('Sale added to your workspace.');
  }

  return <>
    <div className="page-heading-row"><div><h2>Sales performance</h2><p>Track revenue, order volume, and products customers choose.</p></div>
      <div><div className="segmented-control" role="group" aria-label="Sales time period">{['Daily', 'Weekly', 'Monthly'].map((label) => <button key={label} className={period === label ? 'selected' : ''} onClick={() => setPeriod(label)}>{label}</button>)}</div><button className="button-secondary" onClick={() => window.print()}><Download size={14} /> Export</button><button className="button-primary" onClick={() => setShowForm((visible) => !visible)}><ShoppingBag size={14} /> Add sale</button></div>
    </div>
    {showForm && <form className="form-grid sale-form" onSubmit={saveSale}><div className="form-field"><label htmlFor="sale-amount">Sale amount (INR)</label><input id="sale-amount" name="amount" type="number" min="1" step="0.01" placeholder="0.00" required /></div><div className="form-field"><label htmlFor="sale-date">Date</label><input id="sale-date" name="date" type="date" defaultValue={new Date().toISOString().slice(0, 10)} required /></div><div className="form-field"><label htmlFor="sale-customer">Customer (optional)</label><select id="sale-customer" name="customerId"><option value="">Walk-in customer</option>{customers.map((customer) => <option value={customer.id} key={customer.id}>{customer.name}</option>)}</select></div><div className="form-field"><label htmlFor="sale-product">Product (optional)</label><select id="sale-product" name="productId"><option value="">No product linked</option>{products.map((product) => <option value={product.id} key={product.id}>{product.name} · {money(product.price)}</option>)}</select></div><div className="form-field"><label htmlFor="sale-quantity">Quantity</label><input id="sale-quantity" name="quantity" type="number" min="1" step="1" defaultValue="1" required /></div><div className="form-actions"><button className="button-primary" type="submit">Save sale</button></div></form>}
    {notice && <p className="inline-success" role="status">{notice}</p>}
    <section className="kpi-grid sales-kpis">
      <article className="kpi-card"><div className="kpi-head">Total sales<span className="kpi-icon"><IndianRupee size={16} /></span></div><strong className="kpi-value">{money(total)}</strong><div className="kpi-foot">{sales.length} recorded sales</div></article>
      <article className="kpi-card"><div className="kpi-head">Total orders<span className="kpi-icon"><ShoppingBag size={16} /></span></div><strong className="kpi-value">{sales.length}</strong><div className="kpi-foot">From saved transactions</div></article>
      <article className="kpi-card"><div className="kpi-head">Average order value<span className="kpi-icon"><TrendingUp size={16} /></span></div><strong className="kpi-value">{money(sales.length ? Math.round(total / sales.length) : 0)}</strong><div className="kpi-foot">Based on saved sales</div></article>
    </section>
    <article className="panel sales-chart-panel">
      <header className="panel-head"><div><h3>{period} sales</h3><p>Revenue collected by {period.toLowerCase()} interval</p></div><span className="table-count">{chartRows.length} periods recorded</span></header>
      <div className="panel-body">{chartRows.length > 0 ? <div className="large-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={chartRows} margin={{ top: 10, right: 10, left: -12, bottom: 0 }}>
        <CartesianGrid stroke="#e8ebf4" vertical={false} /><XAxis dataKey="day" tickLine={false} axisLine={false} tick={{ fill: '#8a948e', fontSize: 11 }} dy={8} /><YAxis tickLine={false} axisLine={false} tick={{ fill: '#8a948e', fontSize: 10 }} tickFormatter={(value) => `${value / 1000}k`} /><Tooltip formatter={(value) => money(value)} contentStyle={{ border: '1px solid #e1e6f1', borderRadius: 4, fontSize: 12 }} /><Bar dataKey="amount" name="Sales" fill="#8194ff" radius={[3, 3, 0, 0]} maxBarSize={46} />
      </BarChart></ResponsiveContainer></div> : <p className="empty-state">No sales yet. Add your first sale to build this chart.</p>}</div>
    </article>
    <article className="panel sales-product-panel">
      <header className="panel-head"><div><h3>Product-wise sales</h3><p>Best-selling products ranked by units sold</p></div><span className="table-count">{rows.length} products</span></header>
      <div className="data-table-wrap"><table className="business-table"><thead><tr><th>Product</th><th>Category</th><th>Units sold</th><th>Revenue</th><th>Share</th></tr></thead><tbody>{rows.map((product) => <tr key={product.id}><td>{product.name}</td><td>{product.category}</td><td>{product.sold}</td><td>{money(product.sold * product.price)}</td><td><span className="share-track"><i style={{ width: `${Math.min(product.sold / rows[0].sold * 100, 100)}%` }} /></span></td></tr>)}{rows.length === 0 && <tr><td colSpan="5">Product sales will appear after you record sales linked to products.</td></tr>}</tbody></table></div>
    </article>
  </>;
}
