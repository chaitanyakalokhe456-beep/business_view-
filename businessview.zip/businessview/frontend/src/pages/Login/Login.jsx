import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../auth/AuthContext';
import './Login.css';

export default function Login() {
  const navigate = useNavigate();
  const { signIn, signUp, authError } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [mode, setMode] = useState('signin');
  const [message, setMessage] = useState('');
  const [pending, setPending] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();
    const form = Object.fromEntries(new FormData(event.currentTarget).entries());
    setMessage('');
    setPending(true);
    try {
      const authenticate = mode === 'create' ? signUp : signIn;
      await authenticate({ name: form.name, email: form.email, password: form.password });
      navigate('/dashboard');
    } catch (error) {
      setMessage(error.message);
    } finally {
      setPending(false);
    }
  }

  return (
    <main className="login-page">
      <section className="login-story" aria-label="About BusinessView">
        <Link className="login-brand" to="/" aria-label="BusinessView sign in">
          <span className="login-brand-mark" aria-hidden="true" />
          <span>BusinessView</span>
        </Link>
        <img>
            src="/business-growth.png"
            alt="Business growth and analytics"
            className="login-business-image"
        </img>
        <div className="login-story-copy">
          <h1>Spot the startups that need you before they say so.</h1>
          <p>Sales, expenses, stock, and customer trends in one clear workspace.</p>
        </div>
        <img
          className="login-business-image"
          src="/src/pages/Login/login-business-illustration.svg"
          alt="Illustration of a neighborhood shop with a sales chart"
        />
      </section>

      <section className="login-panel" aria-labelledby="login-title">
        <div className="login-form-wrap">
          <h2 id="login-title">{mode === 'signin' ? 'Welcome back' : 'Create your account'}</h2>
          <p className="login-intro">{mode === 'signin' ? 'Sign in to open your workspace.' : 'Create an account to start your workspace.'}</p>

          <div className="login-tabs" role="tablist" aria-label="Account access">
            <button id="signin-tab" type="button" role="tab" aria-selected={mode === 'signin'} aria-controls="login-form-panel" onClick={() => { setMode('signin'); setMessage(''); }}>Sign in</button>
            <button id="create-tab" type="button" role="tab" aria-selected={mode === 'create'} aria-controls="login-form-panel" onClick={() => { setMode('create'); setMessage(''); }}>Create account</button>
          </div>

          <form className="login-form" id="login-form-panel" role="tabpanel" aria-labelledby={mode === 'signin' ? 'signin-tab' : 'create-tab'} onSubmit={handleSubmit}>
            {mode === 'create' && <><label htmlFor="name">Your name</label><input id="name" name="name" type="text" placeholder="Your name" autoComplete="name" required /></>}
            <label htmlFor="email">Email</label>
            <input id="email" name="email" type="email" placeholder="you@business.com" autoComplete="username" required />

            <label htmlFor="password">Password</label>
            <div className="password-field">
              <input id="password" name="password" type={showPassword ? 'text' : 'password'} placeholder="" autoComplete={mode === 'signin' ? 'current-password' : 'new-password'} required minLength={8} />
              <button type="button" className="password-toggle" aria-label={showPassword ? 'Hide password' : 'Show password'} onClick={() => setShowPassword((visible) => !visible)}>
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>

            <button className="login-submit" type="submit" disabled={pending}>{pending ? 'Please wait…' : mode === 'signin' ? 'Sign in' : 'Create account'}</button>
            {(message || authError) && <p className="login-message" role="alert">{message || authError}</p>}
          </form>
        </div>
        <footer className="login-footer">© 2026 BusinessView <span>·</span> <Link to="/home">About BusinessView</Link></footer>
      </section>
    </main>
  );
}
