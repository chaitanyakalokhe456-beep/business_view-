import { Link } from 'react-router-dom';
import './Home.css';

const features = [
  { title: 'Dashboard', description: 'Sales, expenses, profit, orders, and stock on one screen.' },
  { title: 'Sales analysis', description: 'See sales trends and your best-selling products.' },
  { title: 'Expense tracking', description: 'Record expenses and understand where your money goes.' },
  { title: 'Inventory', description: 'Check stock levels and catch low inventory early.' },
  { title: 'Customers', description: 'Keep customer records and spot your most loyal buyers.' },
  { title: 'Reports', description: 'Review sales, expenses, profit, and monthly performance.' },
  { title: 'Alerts', description: 'Surface low stock, falling sales, and rising expenses.' },
  { title: 'AI insights', description: 'Get plain-language tips about your business.', comingSoon: true },
];

const steps = [
  ['Add your products', 'List what you sell and how much stock you have.'],
  ['Record sales and expenses', 'Enter each sale and expense as it happens.'],
  ['Read your numbers', 'See profit, trends, and what needs attention.'],
];

const plans = [
  {
    name: 'Starter',
    price: '₹0',
    billing: '14-day free trial',
    items: ['Dashboard', 'Up to 50 products', 'Sales and expense tracking'],
    action: 'Start free trial',
  },
  {
    name: 'Business',
    price: '₹499',
    billing: 'per month',
    items: ['Everything in Starter', 'Unlimited products', 'Customers and reports', 'Alerts'],
    action: 'Get started',
    featured: true,
  },
  {
    name: 'Pro',
    price: '₹999',
    billing: 'per month',
    items: ['Everything in Business', 'Multiple users', 'Data export', 'AI insights coming soon'],
    action: 'Get started',
  },
];

export default function Home() {
  return (
    <div className="home">
      <header className="nav">
        <div className="wrap nav-in">
          <a href="#top" className="logo"><span className="logo-mark" aria-hidden="true" />BusinessView</a>
          <nav className="nav-links" aria-label="Main navigation">
            <a href="#features">Features</a>
            <a href="#how">How it works</a>
            <a href="#pricing">Pricing</a>
          </nav>
          <Link to="/dashboard" className="btn btn-amber">Get started</Link>
        </div>
      </header>

      <main>
        <section className="hero wrap" id="top">
          <div className="hero-text">
            <p className="eyebrow">A clearer view of your business</p>
            <h1>Understand Your Business Better.</h1>
            <p className="sub">Track sales, expenses, and stock in one simple dashboard, built for small shops and growing businesses.</p>
            <div className="cta-row">
              <Link to="/dashboard" className="btn btn-amber btn-lg">Start free trial</Link>
              <a href="#how" className="btn btn-ghost btn-lg">See how it works</a>
            </div>
            <p className="fine">No card needed. 14 days free.</p>
          </div>

          <div className="preview preview-empty" aria-label="BusinessView dashboard preview">
            <div className="pv-head"><b>Your workspace</b><span>Ready for your records</span></div>
            <div className="pv-empty-mark" aria-hidden="true"><span /><span /><span /></div>
            <div className="pv-empty-copy"><b>Your business, your numbers</b><span>Sales, expenses, and stock appear here after you add your own records.</span></div>
          </div>
        </section>

        <section className="problem">
          <div className="wrap">
            <h2>Most small businesses run on guesswork.</h2>
            <div className="problem-grid">
              <p>Sales stay in a notebook, making it hard to know which products really earn money.</p>
              <p>Expenses pile up quietly, and profit becomes a surprise at the end of the month.</p>
              <p>Stock runs out without warning, and customers go somewhere else.</p>
            </div>
          </div>
        </section>

        <section className="wrap section" id="features">
          <p className="eyebrow">One workspace, the whole picture</p>
          <h2>Everything you need to see your business clearly</h2>
          <div className="feat-grid">
            {features.map((feature) => (
              <article className="feat" key={feature.title}>
                <h3>{feature.title}{feature.comingSoon && <span className="soon">Coming soon</span>}</h3>
                <p>{feature.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="how" id="how">
          <div className="wrap">
            <p className="eyebrow">Start with the essentials</p>
            <h2>Set up in three steps</h2>
            <ol className="steps">
              {steps.map(([title, description], index) => (
                <li key={title}><span className="num">{index + 1}</span><div><h3>{title}</h3><p>{description}</p></div></li>
              ))}
            </ol>
          </div>
        </section>

        <section className="wrap section" id="pricing">
          <p className="eyebrow">Straightforward plans</p>
          <h2>Simple pricing</h2>
          <p className="mut">Sample prices for now. Start free and upgrade when you grow.</p>
          <div className="plans">
            {plans.map((plan) => (
              <article className={`plan${plan.featured ? ' featured' : ''}`} key={plan.name}>
                <h3>{plan.name}</h3>
                <div className="price">{plan.price}<small>{plan.billing}</small></div>
                <ul>{plan.items.map((item) => <li key={item}>{item}</li>)}</ul>
                <Link to="/dashboard" className={`btn ${plan.featured ? 'btn-amber' : 'btn-ghost'}`}>{plan.action}</Link>
              </article>
            ))}
          </div>
        </section>

        <section className="final">
          <div className="wrap final-in">
            <h2>See your numbers, make better decisions.</h2>
            <Link to="/dashboard" className="btn btn-amber btn-lg">Start free trial</Link>
          </div>
        </section>
      </main>

      <footer className="foot"><div className="wrap">© 2026 BusinessView. Understand Your Business Better.</div></footer>
    </div>
  );
}
