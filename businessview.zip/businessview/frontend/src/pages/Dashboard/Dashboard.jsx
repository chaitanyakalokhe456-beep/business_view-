import { Activity, IndianRupee, Package, ShoppingBag, TrendingUp, Wallet } from 'lucide-react';
import { CartesianGrid, ComposedChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { NavLink } from 'react-router-dom';
import { money, useBusinessData } from '../../data/businessData';
import { useAuth } from '../../auth/AuthContext';
import { translate } from '../../utils/localization';

function Metric({ label, value, foot, icon: Icon, warning = false }) {
  return <article className={`kpi-card${warning ? ' kpi-warn' : ''}`}>
    <div className="kpi-head"><span>{label}</span><span className="kpi-icon"><Icon size={16} /></span></div>
    <strong className="kpi-value">{value}</strong>
    <div className="kpi-foot">{foot}</div>
  </article>;
}

export default function Dashboard() {
  const { sales, expenses, products, customers, alerts, profile, dataMode, loadExampleData, clearExampleData } = useBusinessData();
  const { user } = useAuth();
  const t = (key, values) => translate(profile.language, key, values);
  const totalSales = sales.reduce((sum, sale) => sum + sale.amount, 0);
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const isWorkspaceEmpty = sales.length === 0 && expenses.length === 0 && products.length === 0 && customers.length === 0;
  const lowStock = products.filter((product) => product.stock <= product.reorder);
  const topProducts = products.filter((product) => product.sold > 0).toSorted((a, b) => b.sold - a.sold).slice(0, 4);
  const chartGroups = new Map();
  [...sales.map((record) => ({ ...record, kind: 'sales' })), ...expenses.map((record) => ({ ...record, kind: 'expenses' }))].forEach((record) => {
    const date = record.date || new Date().toISOString().slice(0, 10);
    const point = chartGroups.get(date) ?? { date, sales: 0, expenses: 0 };
    point[record.kind] += record.amount;
    chartGroups.set(date, point);
  });
  const chartData = [...chartGroups.values()].sort((left, right) => left.date.localeCompare(right.date)).map((point) => ({
    ...point,
    day: new Date(`${point.date}T00:00:00`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }),
    profit: point.sales - point.expenses,
  }));

  function removeExampleData() {
    if (window.confirm(t('dashboard.clearExampleConfirm'))) clearExampleData();
  }

  return <>
    <div className="page-heading-row">
      <div><h2>{user?.name ? `${t('dashboard.greeting')}, ${user.name}` : t('dashboard.welcome')}</h2><p>{profile.businessName ? `${t('dashboard.businessActivity')} ${profile.businessName}.` : t('dashboard.emptyIntro')}</p></div>
      <span className="date-chip">{t('dashboard.allActivity')}</span>
    </div>

    {dataMode === 'example' && <div className="notice demo-data-banner" role="note"><span><b>{t('dashboard.exampleLabel')}</b> · {t('dashboard.exampleDescription')}</span><button className="button-quiet" type="button" onClick={removeExampleData}>{t('dashboard.clearExample')}</button></div>}

    <section className="kpi-grid" aria-label="Business summary">
      <Metric label={t('dashboard.sales')} value={money(totalSales)} foot={t('dashboard.salesRecorded', { count: sales.length })} icon={IndianRupee} />
      <Metric label={t('dashboard.expenses')} value={money(totalExpenses)} foot={t('dashboard.expensesRecorded', { count: expenses.length })} icon={Wallet} />
      <Metric label={t('dashboard.profit')} value={money(totalSales - totalExpenses)} foot={t('dashboard.profitBasis')} icon={TrendingUp} />
      <Metric label={t('dashboard.orders')} value={sales.length.toLocaleString('en-IN')} foot={t('dashboard.ordersRecorded')} icon={ShoppingBag} />
      <Metric label={t('dashboard.stock')} value={`${products.reduce((sum, product) => sum + product.stock, 0)} ${t('dashboard.units')}`} foot={t('dashboard.lowStockCount', { count: lowStock.length })} icon={Package} warning />
    </section>

    {isWorkspaceEmpty && <section className="getting-started panel"><div><span className="getting-started-kicker">{t('dashboard.startKicker')}</span><h3>{t('dashboard.start')}</h3><p>{t('dashboard.startHint')}</p></div><div className="getting-started-actions"><NavLink className="button-primary" to="/settings">{t('dashboard.businessDetails')}</NavLink><NavLink className="button-secondary" to="/inventory">{t('dashboard.addProducts')}</NavLink><NavLink className="button-secondary" to="/sales">{t('dashboard.recordSale')}</NavLink><NavLink className="button-secondary" to="/expenses">{t('dashboard.addExpense')}</NavLink><button className="button-secondary" type="button" onClick={loadExampleData}>{t('dashboard.loadExample')}</button></div></section>}

    <section className="dashboard-grid">
      <div>
        <article className="panel">
          <header className="panel-head"><div><h3>{t('dashboard.performance')}</h3><p>{t('dashboard.performanceHint')}</p></div><button className="icon-button" aria-label={t('dashboard.chartActivity')}><Activity size={17} /></button></header>
          <div className="panel-body">{chartData.length > 0 ? <><div className="chart-legend"><span><i />{t('dashboard.sales')}</span><span><i />{t('dashboard.expenses')}</span><span><i />{t('dashboard.profit')}</span></div>
            <div className="panel-chart"><ResponsiveContainer width="100%" height="100%"><ComposedChart data={chartData} margin={{ top: 12, right: 8, left: -12, bottom: 0 }}>
              <CartesianGrid stroke="#e8ebf4" vertical={false} />
              <XAxis dataKey="day" tickLine={false} axisLine={false} tick={{ fill: '#8a948e', fontSize: 11 }} dy={8} />
              <YAxis tickLine={false} axisLine={false} tick={{ fill: '#8a948e', fontSize: 10 }} tickFormatter={(value) => `${value / 1000}k`} />
              <Tooltip formatter={(value) => money(value)} contentStyle={{ border: '1px solid #e7ebe7', borderRadius: 4, fontSize: 12 }} />
              <Line type="monotone" dataKey="sales" name="Sales" stroke="#8194ff" strokeWidth={2.5} dot={{ r: 3, fill: '#8194ff' }} activeDot={{ r: 5 }} />
              <Line type="monotone" dataKey="expenses" name="Expenses" stroke="#d5a057" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="profit" name="Profit" stroke="#465b99" strokeWidth={2} dot={false} />
            </ComposedChart></ResponsiveContainer></div></> : <div className="empty-chart-state"><Activity size={24} /><b>{t('dashboard.noChart')}</b><span>{t('dashboard.noChartHint')}</span></div>}
          </div>
        </article>
        <article className="panel">
          <header className="panel-head"><div><h3>{t('dashboard.topProducts')}</h3><p>{t('dashboard.topProductsHint')}</p></div><NavLink className="button-quiet" to="/sales">{t('dashboard.viewSales')}</NavLink></header>
          <div className="panel-body"><div className="product-rank-list">{topProducts.map((product, index) => <div className="product-rank" key={product.id}>
            <span className="rank-number">{index + 1}</span><span className="rank-details"><b>{product.name}</b><small>{product.sold} units sold</small></span><span className="rank-total">{money(product.sold * product.price)}</span>
          </div>)}{topProducts.length === 0 && <p className="empty-state">{t('dashboard.noProducts')}</p>}</div></div>
        </article>
      </div>

      <div>
        <article className="panel">
          <header className="panel-head"><div><h3>{t('dashboard.lowStock')}</h3><p>{t('dashboard.lowStockCount', { count: lowStock.length })}</p></div><NavLink className="button-quiet" to="/inventory">{t('dashboard.viewAll')}</NavLink></header>
          <div className="panel-body">{lowStock.map((product) => <div className="stock-alert" key={product.id}>
            <span className="alert-dot" /><span><b>{product.name}</b><small>Reorder at {product.reorder} units</small></span><span className="stock-count">{product.stock} left</span>
          </div>)}{lowStock.length === 0 && <p className="empty-state">{t('dashboard.addProductsToMonitor')}</p>}</div>
        </article>
        <article className="panel">
          <header className="panel-head"><div><h3>{t('nav.alerts')}</h3><p>{t('dashboard.alertsHint')}</p></div><NavLink className="button-quiet" to="/alerts">{t('dashboard.seeAll')}</NavLink></header>
          <div className="panel-body">{lowStock.length > 0 ? lowStock.slice(0, 3).map((product) => <div className="stock-alert" key={product.id}><span className="alert-dot" /><span><b>{t('dashboard.runningLow', { name: product.name })}</b><small>{t('dashboard.stockLeft', { stock: product.stock, reorder: product.reorder })}</small></span></div>) : alerts.length > 0 ? alerts.slice(0, 3).map((alert) => <div className="stock-alert" key={alert.id}><span className="alert-dot" /><span><b>{alert.title}</b><small>{alert.detail}</small></span></div>) : <p className="empty-state">{t('dashboard.noAlerts')}</p>}</div>
        </article>
        <div className="notice"><Activity size={16} /><span>{t('dashboard.localSave')}</span></div>
      </div>
    </section>
  </>;
}
