import { useMemo, useState } from 'react';
import { Download, Package, Plus, Search } from 'lucide-react';
import { money, useBusinessData } from '../../data/businessData';

export default function Inventory() {
  const { products: items, addProduct, adjustStock } = useBusinessData();
  const [query, setQuery] = useState('');
  const [notice, setNotice] = useState('');
  const [showForm, setShowForm] = useState(false);
  const filtered = useMemo(() => items.filter((item) => `${item.name} ${item.category} ${item.id}`.toLowerCase().includes(query.toLowerCase())), [items, query]);
  const stockValue = items.reduce((sum, product) => sum + product.stock * product.price, 0);
  const lowCount = items.filter((product) => product.stock <= product.reorder).length;

  function saveProduct(event) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    addProduct(Object.fromEntries(form.entries()));
    event.currentTarget.reset();
    setShowForm(false);
    setNotice('Product added to your workspace.');
  }

  return <>
    <div className="page-heading-row"><div><h2>Stock overview</h2><p>Monitor what is available and keep products ready to sell.</p></div><div><button className="button-secondary" onClick={() => window.print()}><Download size={14} /> Export list</button><button className="button-primary" onClick={() => setShowForm((visible) => !visible)}><Plus size={14} /> Add product</button></div></div>
    <section className="kpi-grid inventory-kpis">
      <article className="kpi-card"><div className="kpi-head">Products tracked<span className="kpi-icon"><Package size={16} /></span></div><strong className="kpi-value">{items.length}</strong><div className="kpi-foot"><span>Across {new Set(items.map((item) => item.category)).size} categories</span></div></article>
      <article className="kpi-card"><div className="kpi-head">Units in stock<span className="kpi-icon"><Package size={16} /></span></div><strong className="kpi-value">{items.reduce((sum, item) => sum + item.stock, 0)}</strong><div className="kpi-foot"><span>Current available quantity</span></div></article>
      <article className="kpi-card kpi-warn"><div className="kpi-head">Low-stock products<span className="kpi-icon"><Package size={16} /></span></div><strong className="kpi-value">{lowCount}</strong><div className="kpi-foot"><span>At or below reorder level</span></div></article>
      <article className="kpi-card"><div className="kpi-head">Stock value<span className="kpi-icon"><Package size={16} /></span></div><strong className="kpi-value">{money(stockValue)}</strong><div className="kpi-foot"><span>Based on listed selling prices</span></div></article>
    </section>
    {notice && <p className="inline-success" role="status">{notice} Your records are saved in this browser.</p>}
    <article className="panel">
      <header className="panel-head"><div><h3>Product stock</h3><p>Available stock, sales, and replenishment levels</p></div><label className="search-field"><Search size={15} /><input value={query} onChange={(event) => setQuery(event.target.value)} aria-label="Search products" placeholder="Search products" /></label></header>
      {showForm && <form className="form-grid product-form" onSubmit={saveProduct}>
        <div className="form-field"><label htmlFor="product-name">Product name</label><input id="product-name" name="name" placeholder="Product name" required /></div>
        <div className="form-field"><label htmlFor="product-sku">SKU (optional)</label><input id="product-sku" name="sku" placeholder="Auto-generated if empty" /></div>
        <div className="form-field"><label htmlFor="product-category">Category</label><input id="product-category" name="category" placeholder="Category" required /></div>
        <div className="form-field"><label htmlFor="product-stock">Opening stock</label><input id="product-stock" name="stock" type="number" min="0" step="1" defaultValue="0" required /></div>
        <div className="form-field"><label htmlFor="product-reorder">Low-stock level</label><input id="product-reorder" name="reorder" type="number" min="0" step="1" defaultValue="5" required /></div>
        <div className="form-field"><label htmlFor="product-price">Unit price (INR)</label><input id="product-price" name="price" type="number" min="0" step="0.01" placeholder="0.00" required /></div>
        <div className="form-actions"><button className="button-primary" type="submit"><Plus size={14} /> Save product</button></div>
      </form>}
      <div className="data-table-wrap"><table className="business-table"><thead><tr><th>Product</th><th>SKU</th><th>Category</th><th>Available</th><th>Stock value</th><th>Sold</th><th>Status</th><th>Adjust stock</th></tr></thead><tbody>
        {filtered.map((product) => <tr key={product.id}><td>{product.name}</td><td>{product.sku}</td><td>{product.category}</td><td>{product.stock} units</td><td>{money(product.stock * product.price)}</td><td>{product.sold} units</td><td><span className={`status-pill ${product.stock <= product.reorder ? 'status-low' : 'status-good'}`}>{product.stock <= product.reorder ? 'Low stock' : 'In stock'}</span></td><td><span className="stock-actions"><button className="stock-step" onClick={() => { adjustStock(product.id, 1); setNotice('Stock quantity increased.'); }} aria-label={`Add one ${product.name}`}>+</button><button className="stock-step" onClick={() => { adjustStock(product.id, -1); setNotice('One unit marked as sold.'); }} aria-label={`Mark one ${product.name} sold`}>−</button></span></td></tr>)}
        {filtered.length === 0 && <tr><td colSpan="8">{items.length === 0 ? 'No products yet. Add your first product above.' : 'No products match your search.'}</td></tr>}
      </tbody></table></div>
      <footer className="table-footer"><span>Showing {filtered.length} of {items.length} products</span><span>Saved in this browser</span></footer>
    </article>
  </>;
}
