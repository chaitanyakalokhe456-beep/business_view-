import { useState } from 'react';
import { IndianRupee, Plus, Wallet } from 'lucide-react';
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import { money, useBusinessData } from '../../data/businessData';

const palette = ['#8194ff', '#d5a057', '#465b99', '#9b715a', '#9aa7c4'];

export default function Expenses() {
  const { expenses: rows, addExpense: saveExpense } = useBusinessData();
  const [notice, setNotice] = useState('');
  const total = rows.reduce((sum, row) => sum + Number(row.amount), 0);
  const categories = Object.values(rows.reduce((groups, row) => {
    groups[row.category] = groups[row.category] ?? { name: row.category, value: 0 };
    groups[row.category].value += Number(row.amount);
    return groups;
  }, {})).sort((a, b) => b.value - a.value);

  function addExpense(event) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const row = { category: form.get('category'), amount: Number(form.get('amount')), date: form.get('date'), note: form.get('note') };
    saveExpense(row);
    event.currentTarget.reset();
    setNotice('Expense added to your workspace.');
  }

  return <>
    <div className="page-heading-row"><div><h2>Spending overview</h2><p>Record costs and see where business funds are going.</p></div><button className="button-primary" onClick={() => document.querySelector('#expense-description')?.focus()}><Plus size={15} /> Add expense</button></div>
    <section className="kpi-grid expense-kpis">
      <article className="kpi-card"><div className="kpi-head">Recorded expenses<span className="kpi-icon"><Wallet size={16} /></span></div><strong className="kpi-value">{money(total)}</strong><div className="kpi-foot">{rows.length} entries</div></article>
      <article className="kpi-card"><div className="kpi-head">Highest category<span className="kpi-icon"><IndianRupee size={16} /></span></div><strong className="kpi-value">{categories[0]?.name ?? 'None'}</strong><div className="kpi-foot"><span>{money(categories[0]?.value ?? 0)}</span><span>of tracked expenses</span></div></article>
      <article className="kpi-card"><div className="kpi-head">Recorded expenses<span className="kpi-icon"><Plus size={16} /></span></div><strong className="kpi-value">{rows.length}</strong><div className="kpi-foot"><span>This month</span></div></article>
    </section>
    <section className="expenses-grid">
      <article className="panel"><header className="panel-head"><div><h3>Add an expense</h3><p>Enter a business cost to track it in this view</p></div></header>
        <form className="form-grid" onSubmit={addExpense}>
          <div className="form-field"><label htmlFor="expense-description">Description</label><input id="expense-description" name="note" placeholder="e.g. Supplier payment" required /></div>
          <div className="form-field"><label htmlFor="expense-amount">Amount (INR)</label><input id="expense-amount" name="amount" type="number" min="1" step="1" placeholder="0" required /></div>
          <div className="form-field"><label htmlFor="expense-category">Category</label><select id="expense-category" name="category"><option>Inventory</option><option>Rent</option><option>Utilities</option><option>Staff</option><option>Delivery</option><option>Marketing</option><option>Other</option></select></div>
          <div className="form-field"><label htmlFor="expense-date">Date</label><input id="expense-date" name="date" type="date" defaultValue={new Date().toISOString().slice(0, 10)} required /></div>
          <div className="form-actions"><button className="button-primary" type="submit"><Plus size={14} /> Save expense</button></div>
        </form>
        {notice && <p className="inline-success" role="status">{notice}</p>}
        <header className="panel-head"><div><h3>Recent expenses</h3><p>Latest recorded business costs</p></div></header>
        <div className="data-table-wrap"><table className="business-table"><thead><tr><th>Description</th><th>Category</th><th>Date</th><th>Amount</th></tr></thead><tbody>{rows.map((row, index) => <tr key={`${row.date}-${index}`}><td>{row.note}</td><td>{row.category}</td><td>{row.date}</td><td>{money(Number(row.amount))}</td></tr>)}</tbody></table></div>
      </article>
      <article className="panel"><header className="panel-head"><div><h3>Expense categories</h3><p>Share of recorded spending</p></div></header><div className="panel-body">{categories.length > 0 ? <><div className="expense-chart"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={categories} dataKey="value" nameKey="name" innerRadius="58%" outerRadius="82%" paddingAngle={3}>{categories.map((item, index) => <Cell key={item.name} fill={palette[index % palette.length]} />)}</Pie><Tooltip formatter={(value) => money(value)} contentStyle={{ border: '1px solid #e7ebe7', borderRadius: 4, fontSize: 12 }} /></PieChart></ResponsiveContainer><div className="donut-total"><b>{money(total)}</b><small>Total tracked</small></div></div>
        <div className="category-list">{categories.map((item, index) => <div key={item.name}><span><i style={{ background: palette[index % palette.length] }} />{item.name}</span><b>{money(item.value)}</b></div>)}</div></> : <p className="empty-state">Add an expense to see your spending categories here.</p>}
      </div></article>
    </section>
  </>;
}
