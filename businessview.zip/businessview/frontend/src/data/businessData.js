import { useSyncExternalStore } from 'react';

const STORAGE_KEY = 'businessview.workspace.v1';

export const emptyBusinessData = {
  sales: [],
  expenses: [],
  products: [],
  customers: [],
  alerts: [],
  profile: { businessName: '', businessType: '', email: '', address: '', ownerName: '', ownerEmail: '', currency: 'INR', language: 'en' },
};

function loadData(key) {
  if (!key) return emptyBusinessData;
  try {
    const saved = JSON.parse(window.localStorage.getItem(key) ?? 'null');
    return saved ? { ...emptyBusinessData, ...saved, profile: { ...emptyBusinessData.profile, ...saved.profile } } : emptyBusinessData;
  } catch {
    return emptyBusinessData;
  }
}

function dateDaysAgo(days) {
  const date = new Date();
  date.setUTCHours(0, 0, 0, 0);
  date.setUTCDate(date.getUTCDate() - days);
  return date.toISOString().slice(0, 10);
}

function createExampleData(profile) {
  const products = [
    { id: 'example-product-rice', name: 'Basmati Rice · 5kg', sku: 'CM-RICE-5K', category: 'Grocery', stock: 14, reorder: 8, price: 620, sold: 0 },
    { id: 'example-product-oil', name: 'Sunflower Oil · 1L', sku: 'CM-OIL-001', category: 'Grocery', stock: 9, reorder: 10, price: 165, sold: 0 },
    { id: 'example-product-tea', name: 'Premium Tea · 500g', sku: 'CM-TEA-500', category: 'Beverages', stock: 18, reorder: 8, price: 280, sold: 0 },
    { id: 'example-product-sugar', name: 'Sugar · 1kg', sku: 'CM-SUG-001', category: 'Grocery', stock: 24, reorder: 10, price: 52, sold: 0 },
    { id: 'example-product-soap', name: 'Bath Soap · 4 pack', sku: 'CM-SOAP-4P', category: 'Household', stock: 6, reorder: 10, price: 145, sold: 0 },
  ];
  const customerProfiles = [
    { id: 'example-customer-anaya', name: 'Anaya Sharma', email: 'anaya@example.test' },
    { id: 'example-customer-rohan', name: 'Rohan Mehta', email: 'rohan@example.test' },
    { id: 'example-customer-sana', name: 'Sana Iyer', email: 'sana@example.test' },
    { id: 'example-customer-vikram', name: 'Vikram Rao', email: 'vikram@example.test' },
  ];
  const transactions = [
    { product: 0, quantity: 2, customer: 0, daysAgo: 85 },
    { product: 1, quantity: 4, customer: 1, daysAgo: 78 },
    { product: 2, quantity: 2, customer: 2, daysAgo: 70 },
    { product: 3, quantity: 12, customer: 3, daysAgo: 63 },
    { product: 4, quantity: 3, customer: 0, daysAgo: 56 },
    { product: 0, quantity: 3, customer: 1, daysAgo: 48 },
    { product: 2, quantity: 4, customer: 2, daysAgo: 41 },
    { product: 1, quantity: 6, customer: 3, daysAgo: 34 },
    { product: 3, quantity: 16, customer: 0, daysAgo: 27 },
    { product: 4, quantity: 5, customer: 1, daysAgo: 19 },
    { product: 0, quantity: 4, customer: 2, daysAgo: 11 },
    { product: 2, quantity: 5, customer: 3, daysAgo: 4 },
  ];
  const sales = transactions.map(({ product: productIndex, quantity, customer: customerIndex, daysAgo }, index) => {
    const product = products[productIndex];
    product.sold += quantity;
    return {
      id: `example-sale-${index + 1}`,
      date: dateDaysAgo(daysAgo),
      amount: product.price * quantity,
      customerId: customerProfiles[customerIndex].id,
      items: [{ productId: product.id, quantity, unitPrice: product.price }],
    };
  }).toReversed();
  const customers = customerProfiles.map((customer) => {
    const purchases = sales.filter((sale) => sale.customerId === customer.id);
    return {
      ...customer,
      visits: purchases.length,
      spent: purchases.reduce((total, sale) => total + sale.amount, 0),
      lastPurchase: purchases[0]?.date ?? 'No purchases yet',
    };
  });

  return {
    ...emptyBusinessData,
    dataMode: 'example',
    profile: {
      ...profile,
      businessName: profile.businessName || 'City Mart',
      businessType: profile.businessType || 'Retail store',
    },
    products,
    customers,
    sales,
    expenses: [
      { id: 'example-expense-1', note: 'Shop rent', category: 'Rent', amount: 18000, date: dateDaysAgo(75) },
      { id: 'example-expense-2', note: 'Grocery restock', category: 'Inventory', amount: 12400, date: dateDaysAgo(63) },
      { id: 'example-expense-3', note: 'Staff wages', category: 'Staff', amount: 14500, date: dateDaysAgo(49) },
      { id: 'example-expense-4', note: 'Electricity bill', category: 'Utilities', amount: 3200, date: dateDaysAgo(34) },
      { id: 'example-expense-5', note: 'Delivery and transport', category: 'Delivery', amount: 1800, date: dateDaysAgo(19) },
      { id: 'example-expense-6', note: 'Shop supplies', category: 'Other', amount: 950, date: dateDaysAgo(5) },
    ],
  };
}

function removeLegacySampleData(data) {
  const sampleId = (record) => typeof record.id === 'string' && record.id.startsWith('sample-');
  const sampleProductIds = new Set(data.products.filter(sampleId).map((product) => product.id));
  const sampleCustomerIds = new Set(data.customers.filter(sampleId).map((customer) => customer.id));
  const hasLegacySamples = data.dataMode === 'demo'
    || [...data.sales, ...data.expenses, ...data.products, ...data.customers, ...data.alerts].some(sampleId);
  if (!hasLegacySamples) return data;

  const demoProfile = data.demoProfile ?? {};
  const profile = { ...data.profile };
  const sampleProfile = { businessName: 'Green Corner Market', businessType: 'Retail store', address: 'Pune, Maharashtra' };
  for (const key of ['businessName', 'businessType', 'address']) {
    if (demoProfile[key] !== undefined) profile[key] = profile[key] || demoProfile[key];
    if (profile[key] === sampleProfile[key] && demoProfile[key] === '') profile[key] = '';
  }

  const migrated = {
    ...data,
    sales: data.sales.filter((sale) => !sampleId(sale)).map((sale) => ({
      ...sale,
      customerId: sampleCustomerIds.has(sale.customerId) ? '' : sale.customerId,
      items: (sale.items ?? []).filter((item) => !sampleProductIds.has(item.productId)),
    })),
    expenses: data.expenses.filter((expense) => !sampleId(expense)),
    products: data.products.filter((product) => !sampleId(product)),
    customers: data.customers.filter((customer) => !sampleId(customer)),
    alerts: data.alerts.filter((alert) => !sampleId(alert)),
    profile,
  };
  const cleaned = { ...migrated };
  delete cleaned.dataMode;
  delete cleaned.demoProfile;
  return cleaned;
}

function removeLegacyDemoFlags(data) {
  if (!Object.hasOwn(data, 'demoProfile') && data.dataMode !== 'demo') return data;
  const cleaned = { ...data };
  if (cleaned.dataMode === 'demo') delete cleaned.dataMode;
  delete cleaned.demoProfile;
  return cleaned;
}

let storageKey = null;
let snapshot = emptyBusinessData;
const listeners = new Set();

function subscribe(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function getSnapshot() {
  return snapshot;
}

function saveSnapshot() {
  if (!storageKey) return;
  try {
    window.localStorage.setItem(storageKey, JSON.stringify(snapshot));
  } catch {
    // Keep this session usable if browser storage is unavailable.
  }
}

function commit(update) {
  snapshot = typeof update === 'function' ? update(snapshot) : { ...snapshot, ...update };
  saveSnapshot();
  listeners.forEach((listener) => listener());
}

if (typeof window !== 'undefined') {
  window.addEventListener('storage', (event) => {
    if (event.key === storageKey) {
      snapshot = loadData(storageKey);
      listeners.forEach((listener) => listener());
    }
  });
}

export function setWorkspaceUser(userId) {
  const nextStorageKey = userId ? `${STORAGE_KEY}.${userId}` : null;
  if (storageKey === nextStorageKey) return;
  storageKey = nextStorageKey;
  snapshot = loadData(storageKey);
  if (storageKey) {
    const migrated = removeLegacyDemoFlags(removeLegacySampleData(snapshot));
    if (migrated !== snapshot) {
      snapshot = migrated;
      saveSnapshot();
    }
  }
  listeners.forEach((listener) => listener());
}

const makeId = (prefix) => `${prefix}-${globalThis.crypto?.randomUUID?.() ?? Date.now().toString(36)}`;

export function useBusinessData() {
  const data = useSyncExternalStore(subscribe, getSnapshot, getSnapshot);

  return {
    ...data,
    addExpense(expense) {
      commit((current) => ({ ...current, expenses: [{ ...expense, id: makeId('expense'), amount: Number(expense.amount) }, ...current.expenses] }));
    },
    addAlert(alert) {
      const id = makeId('alert');
      commit((current) => ({ ...current, alerts: [{ ...alert, id }, ...current.alerts] }));
      return id;
    },
    removeAlert(alertId) {
      commit((current) => ({ ...current, alerts: current.alerts.filter((alert) => alert.id !== alertId) }));
    },
    addProduct(product) {
      const id = makeId('product');
      commit((current) => ({ ...current, products: [{ ...product, id, sku: product.sku || id.toUpperCase(), stock: Number(product.stock), reorder: Number(product.reorder), price: Number(product.price), sold: 0 }, ...current.products] }));
    },
    addCustomer(customer) {
      const id = makeId('customer');
      commit((current) => ({ ...current, customers: [{ ...customer, id, visits: 0, spent: 0, lastPurchase: 'No purchases yet' }, ...current.customers] }));
      return id;
    },
    addSale(sale) {
      const items = (sale.items ?? []).map((item) => ({ ...item, quantity: Number(item.quantity), unitPrice: Number(item.unitPrice) }));
      commit((current) => {
        const amount = Number(sale.amount) || items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
        const nextProducts = current.products.map((product) => {
          const soldItem = items.find((item) => item.productId === product.id);
          return soldItem ? { ...product, stock: Math.max(0, product.stock - soldItem.quantity), sold: product.sold + soldItem.quantity } : product;
        });
        const nextCustomers = current.customers.map((customer) => customer.id === sale.customerId
          ? { ...customer, visits: customer.visits + 1, spent: customer.spent + amount, lastPurchase: sale.date }
          : customer);
        return { ...current, products: nextProducts, customers: nextCustomers, sales: [{ ...sale, id: makeId('sale'), amount, items }, ...current.sales] };
      });
    },
    adjustStock(productId, amount) {
      commit((current) => ({ ...current, products: current.products.map((product) => product.id === productId ? { ...product, stock: Math.max(0, product.stock + Number(amount)) } : product) }));
    },
    updateProfile(profile) {
      commit((current) => ({ ...current, profile: { ...current.profile, ...profile } }));
    },
    clearWorkspace() {
      commit(emptyBusinessData);
    },
    loadExampleData() {
      const hasRecords = snapshot.sales.length > 0 || snapshot.expenses.length > 0
        || snapshot.products.length > 0 || snapshot.customers.length > 0;
      if (!hasRecords) commit(createExampleData(snapshot.profile));
    },
    clearExampleData() {
      if (snapshot.dataMode !== 'example') return;
      commit({ ...emptyBusinessData, dataMode: 'custom', profile: snapshot.profile });
    },
  };
}

export const money = (amount, currency = snapshot.profile.currency || 'INR') => new Intl.NumberFormat('en-IN', {
  style: 'currency', currency, maximumFractionDigits: 0,
}).format(Number(amount) || 0);
